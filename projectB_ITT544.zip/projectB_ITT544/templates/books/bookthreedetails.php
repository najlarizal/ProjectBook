
     <section>
          <div class="container">
               <div class="row">
                    <div class="col-md-6 col-xs-9">
                         <div>
                              <img src="/projectB_ITT544/webroot/img/bookthree.jpg" alt="" class="img-responsive wc-image">
                         </div>
                         <br>
                         <div class="row">
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/booktwo.jpg" alt="" class="img-responsive">
                                   </div>
									<div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwodetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookfour.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfourdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookfive.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfivedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-xs-12">
                         <form action="#" method="post" class="form">
                              <h2>SAFE WITH ME</h2>

                              <p class="lead">Written by K.L Slater</p>
                              
                              <p class="lead"><strong class="text-primary">MYR39.90</strong></p>

                              <div class="row">
									 <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sellers</strong>
                                             <br>
                                             <span>Best Sellers</span>
                                        </p>
                                   </div>
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Old/New</strong>
                                             <br>
                                             <span>Old Books</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Make</strong>
                                             <br>
                                             <span>K.L Slater</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Genre</strong>
                                             <br>
                                             <span>Thriller</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Languages</strong>
                                             <br>
                                             <span>English</span>
                                        </p>
                                   </div>
									
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Pages</strong>
                                             <br>
                                             <span>440 Pages</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Cover</strong>
                                             <br>
                                             <span>Soft Cover</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Rating</strong>
                                             <br>
                                             <span>5/5</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Publication Date</strong>
                                             <br>
                                             <span>02 February 2005</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Price</strong>
                                             <br>
                                             <span>MYR39.90</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>ISBN</strong>
                                             <br>
                                             <span>127653890276</span>
                                        </p>
                                   </div>
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sold</strong>
                                             <br>
                                             <span>45800 Sold</span>
                                        </p>
                                   </div>
                              </div>
                         </form>
                    </div>
               </div>

               <div class="row">
                    <div class="col-lg-8 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Synopsis</h4>
                              </div>

                              <div class="panel-body">
                                   <p>Anna lives a solitary existence, taking solace in order and routine. 
								   Her only friend is the lonely old lady next door. She doesn’t like to 
								   let people get too close – she knows how much damage they can do.</p>
								   <p>Then one ordinary day Anna witnesses a devastating road accident and 
								   recognises the driver as Carla, the woman who ruined her life all those
								   years ago. Now it’s Anna’s chance to set things straight but her revenge 
								   needs to be executed carefully</p>
								   <p>First she needs to get to know Liam, the man injured in the accident. 
								   She needs to follow the police investigation. She needs to watch Carla from 
								   the shadows</p>
								   <p>But as Anna’s obsession with Carla escalates, her own secrets start to 
								   unravel. Is Carla really dangerous or does Anna need to worry about someone 
								   far closer to home?</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Contact Details</h4>
                              </div>

                              <div class="panel-body">
                                   <p>
                                        <span>Name</span>
                                        <br>
                                        <strong>Encik Misteri</strong>
                                   </p>

                                   <p>
                                        <span>Phone</span>
                                        <br>
                                        <strong><a href="019-6542143">019-6542143</a></strong>
                                   </p>

                                   <p>
                                        <span>Email</span>
                                        <br>
                                        <strong><a href="misteri@gmail.com">misteri@gmail.com</a></strong>
                                   </p>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>