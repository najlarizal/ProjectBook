
     <section>
          <div class="container">
               <div class="row">
                    <div class="col-md-6 col-xs-9">
                         <div>
                              <img src="/projectB_ITT544/webroot/img/bookfour.jpg" alt="" class="img-responsive wc-image">
                         </div>
                         <br>
                         <div class="row">
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookthree.jpg" alt="" class="img-responsive">
                                   </div>
									<div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookfive.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/booksix.jpg" alt="" class="img-responsive">
                                   </div>
								    <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'booksixdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-xs-12">
                         <form action="#" method="post" class="form">
                              <h2>MAZE RUNNER : THE DEATH CURE</h2>

                              <p class="lead">Written by James Dashner</p>
                              
                              <p class="lead"><strong class="text-primary">MYR45.00</strong></p>

                              <div class="row">
									 <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sellers</strong>
                                             <br>
                                             <span>New Releases</span>
                                        </p>
                                   </div>
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Old/New</strong>
                                             <br>
                                             <span>New Books</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Make</strong>
                                             <br>
                                             <span>James Dashner</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Genre</strong>
                                             <br>
                                             <span>Mystery & Romance</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Languages</strong>
                                             <br>
                                             <span>English</span>
                                        </p>
                                   </div>
									
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Pages</strong>
                                             <br>
                                             <span>537 Pages</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Cover</strong>
                                             <br>
                                             <span>Soft Cover</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Rating</strong>
                                             <br>
                                             <span>5/5</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Publication Date</strong>
                                             <br>
                                             <span>19 December 2010</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Price</strong>
                                             <br>
                                             <span>MYR45.90</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>ISBN</strong>
                                             <br>
                                             <span>764298076512</span>
                                        </p>
                                   </div>
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sold</strong>
                                             <br>
                                             <span>76500 Sold</span>
                                        </p>
                                   </div>
                              </div>
                         </form>
                    </div>
               </div>

               <div class="row">
                    <div class="col-lg-8 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Synopsis</h4>
                              </div>

                              <div class="panel-body">
                                   <p>Thomas has been running around ragged during the first two books 
								   of The Maze Runner series: first he had to escape the Maze with his 
								   Glader friends in Book One; then, in Book Two, he had to endure the 
								   Scorch Trials, a deadly trek through a hot, barren wasteland. 
								   Talk about having a bad few weeks.</p>
								   <p>Well, at the end of Book Two, we left Thomas in a white room, alone. 
								   He just completed the Scorch Trials, and word has it that he has the 
								   Flare, so WICKED has him quarantined. Ah, what a life it is.</p>
								   <p>We pick up where we left off: Thomas is in that same white room. 
								   He has to stay in isolation for 26 days before they finally open the 
								   door. We'll give it to you straight: Thomas ain't so happy with WICKED.</p>
								   <p>Yeah, well, happy or not, they let him out, and Rat Man, the dude who 
								   gave Thomas his orders for the Scorch Trials, escorts him into a room 
								   full of his Glader pals. So everyone is back together.</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Contact Details</h4>
                              </div>

                              <div class="panel-body">
                                   <p>
                                        <span>Name</span>
                                        <br>
                                        <strong>Encik Misteri</strong>
                                   </p>

                                   <p>
                                        <span>Phone</span>
                                        <br>
                                        <strong><a href="019-6542143">019-6542143</a></strong>
                                   </p>

                                   <p>
                                        <span>Email</span>
                                        <br>
                                        <strong><a href="misteri@gmail.com">misteri@gmail.com</a></strong>
                                   </p>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>