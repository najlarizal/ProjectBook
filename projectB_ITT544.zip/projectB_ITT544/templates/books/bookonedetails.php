
     <section>
          <div class="container">
               <div class="row">
                    <div class="col-md-6 col-xs-9">
                         <div>
                              <img src="/projectB_ITT544/webroot/img/bookone.jpg" alt="" class="img-responsive wc-image">
                         </div>
                         <br>
                         <div class="row">
                            <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/booktwo.jpg" alt="" class="img-responsive">
                                   </div>
								<div class="courses-info">
                                        <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwodetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                </div>
                                <br>
                            </div>
							
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookthree.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookfour.jpg" alt="" class="img-responsive">
                                   </div>
									<div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfourdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-xs-12">
                         <form action="#" method="post" class="form">
                              <h2>WUTHERING HEIGHTS</h2>

                              <p class="lead">Written by Emily Bronte</p>
                              
                              <p class="lead"><strong class="text-primary">MYR35.50</strong></p>

                              <div class="row">
									 <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sellers</strong>
                                             <br>
                                             <span>Best Sellers</span>
                                        </p>
                                   </div>
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Old/New</strong>
                                             <br>
                                             <span>Old Books</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Make</strong>
                                             <br>
                                             <span>Emily Bronte</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Genre</strong>
                                             <br>
                                             <span>Mystery</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Languages</strong>
                                             <br>
                                             <span>English</span>
                                        </p>
                                   </div>
									
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Pages</strong>
                                             <br>
                                             <span>313 Pages</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Cover</strong>
                                             <br>
                                             <span>Hard Cover</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Rating</strong>
                                             <br>
                                             <span>4.5/5</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Publication Date</strong>
                                             <br>
                                             <span>03 September 2005</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Price</strong>
                                             <br>
                                             <span>MYR35.50</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>ISBN</strong>
                                             <br>
                                             <span>879645123407</span>
                                        </p>
                                   </div>
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sold</strong>
                                             <br>
                                             <span>27500 Sold</span>
                                        </p>
                                   </div>
                              </div>
                         </form>
                    </div>
               </div>

               <div class="row">
                    <div class="col-lg-8 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Synopsis</h4>
                              </div>

                              <div class="panel-body">
                                   <p> In 1801, Lockwood, a wealthy young man from the South of England who is seeking peace and 
								   recuperation, rents Thrushcross Grange in Yorkshire. He visits his landlord, Heathcliff, who 
								   lives in a remote moorland farmhouse, Wuthering Heights.</p>
								   <p>There Lockwood finds an odd assemblage: Heathcliff who seems to be a gentleman, but his manners are uncouth; the reserved mistress of the 
								   house who is in her mid-teens; and a young man who seems to be a member of the family, yet dresses 
								   and speaks as if he is a servant.</p>
								   <p>Snowed in, Lockwood is grudgingly allowed to stay and is shown to a bedchamber where he notices 
								   books and graffiti left by a former inhabitant named Catherine. He falls asleep and has a nightmare 
								   in which he sees the ghostly Catherine trying to enter through the window.</p>
								   <p>He cries out in fear,rousing Heathcliff, who rushes into the room. Lockwood is convinced that what he saw was real. 
								   Heathcliff, believing Lockwood to be right, examines the window and opens it, hoping to allow 
								   Catherine's spirit to enter. When nothing happens, Heathcliff shows Lockwood to his own bedroom and 
								   returns to keep watch at the window.</p>
								   <p>At sunrise, Heathcliff escorts Lockwood back to Thrushcross Grange. Lockwood asks the housekeeper, 
								   Nelly Dean, about the family at Wuthering Heights, and she tells him the truth.</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Contact Details</h4>
                              </div>

                              <div class="panel-body">
                                   <p>
                                        <span>Name</span>
                                        <br>
                                        <strong>Encik Misteri</strong>
                                   </p>

                                   <p>
                                        <span>Phone</span>
                                        <br>
                                        <strong><a href="019-6542143">019-6542143</a></strong>
                                   </p>

                                   <p>
                                        <span>Email</span>
                                        <br>
                                        <strong><a href="misteri@gmail.com">misteri@gmail.com</a></strong>
                                   </p>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>
	 