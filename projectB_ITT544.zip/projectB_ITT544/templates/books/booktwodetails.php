<section>
          <div class="container">
               <div class="row">
                    <div class="col-md-6 col-xs-9">
                        <div>
                              <img src="/projectB_ITT544/webroot/img/booktwo.jpg" alt="" class="img-responsive wc-image">
                        </div>
                         <br>
                         <div class="row">
                            <div class="col-sm-4 col-xs-6">
									<div>
                                        <img src="/projectB_ITT544/webroot/img/bookone.jpg" alt="" class="img-responsive">
									</div>
									<div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookonedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                             </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookthree.jpg" alt="" class="img-responsive">
                                   </div>
									<div class="courses-info">
                                        <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
								    </div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookfour.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfourdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-xs-12">
                         <form action="#" method="post" class="form">
                              <h2>THE SPIDER GODDESS</h2>

                              <p class="lead">Written by Tara Moss</p>
                              
                              <p class="lead"><strong class="text-primary">MYR33.50</strong></p>

                              <div class="row">
									 <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sellers</strong>
                                             <br>
                                             <span>Best Sellers</span>
                                        </p>
                                   </div>
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Old/New</strong>
                                             <br>
                                             <span>Old Books</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Make</strong>
                                             <br>
                                             <span>Tara Moss</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Genre</strong>
                                             <br>
                                             <span>Horror</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Languages</strong>
                                             <br>
                                             <span>English</span>
                                        </p>
                                   </div>
									
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Pages</strong>
                                             <br>
                                             <span>415 Pages</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Cover</strong>
                                             <br>
                                             <span>Hard Cover</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Rating</strong>
                                             <br>
                                             <span>4.5/5</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Publication Date</strong>
                                             <br>
                                             <span>26 June 2007</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Price</strong>
                                             <br>
                                             <span>MYR33.50</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>ISBN</strong>
                                             <br>
                                             <span>356217650987</span>
                                        </p>
                                   </div>
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sold</strong>
                                             <br>
                                             <span>35300 Sold</span>
                                        </p>
                                   </div>
                              </div>
                         </form>
                    </div>
               </div>

               <div class="row">
                    <div class="col-lg-8 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Synopsis</h4>
                              </div>

                              <div class="panel-body">
                                   <p>It's been two months since Pandora English left her small hometown to live with 
								   her mysterious great-aunt in a haunted mansion in Spektor, the fog-wreathed suburb 
								   of Manhattan that doesn't appear on any map.</p>
								   <p>With the help of her great-aunt and the beautiful, but dead, Lieutenant Luke, 
								   Pandora is beginning to understand the significance of the Lucasta family heritage 
								   her late mother kept secret from her. Pandora is heir to a great gift - a gift that 
								   comes with a frightening responsibility. And when a new designer arrives in town, 
								   Pandora soon discovers that this designer's ambitions extend far beyond taking over 
								   the fashion world, one knit at a time.</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Contact Details</h4>
                              </div>

                              <div class="panel-body">
                                   <p>
                                        <span>Name</span>
                                        <br>
                                        <strong>Encik Misteri</strong>
                                   </p>

                                   <p>
                                        <span>Phone</span>
                                        <br>
                                        <strong><a href="019-6542143">019-6542143</a></strong>
                                   </p>

                                   <p>
                                        <span>Email</span>
                                        <br>
                                        <strong><a href="misteri@gmail.com">misteri@gmail.com</a></strong>
                                   </p>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>