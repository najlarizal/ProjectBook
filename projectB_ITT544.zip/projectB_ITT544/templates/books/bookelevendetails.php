
     <section>
          <div class="container">
               <div class="row">
                    <div class="col-md-6 col-xs-9">
                         <div>
                              <img src="/projectB_ITT544/webroot/img/bookeleven.jpg" alt="" class="img-responsive wc-image">
                         </div>
                         <br>
                         <div class="row">
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookten.jpg"" alt="" class="img-responsive">
                                   </div>
									<div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktendetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
									</div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/booktwelve.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwelvedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
								   </div>
                                   <br>
                              </div>
                              <div class="col-sm-4 col-xs-6">
                                   <div>
                                        <img src="/projectB_ITT544/webroot/img/bookone.jpg" alt="" class="img-responsive">
                                   </div>
								   <div class="courses-info">
										<a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookonedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
								   </div>
                                   <br>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-xs-12">
                         <form action="#" method="post" class="form">
                              <h2>TO ALL THE BOYS I'VE LOVED BEFORE</h2>

                              <p class="lead">Written by Jenny Han</p>
                              
                              <p class="lead"><strong class="text-primary">MYR36.80</strong></p>

                              <div class="row">
									 <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sellers</strong>
                                             <br>
                                             <span>New Releases</span>
                                        </p>
                                   </div>
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Old/New</strong>
                                             <br>
                                             <span>New Books</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Make</strong>
                                             <br>
                                             <span>Jenny Han</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Genre</strong>
                                             <br>
                                             <span>Romantic</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Languages</strong>
                                             <br>
                                             <span>English</span>
                                        </p>
                                   </div>
									
                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Pages</strong>
                                             <br>
                                             <span>455 Pages</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Cover</strong>
                                             <br>
                                             <span>Soft Cover</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Rating</strong>
                                             <br>
                                             <span>5/5</span>
                                        </p>
                                   </div>

                                   <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Publication Date</strong>
                                             <br>
                                             <span>25 April 2010</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Price</strong>
                                             <br>
                                             <span>MYR36.80</span>
                                        </p>
                                   </div>
								   
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>ISBN</strong>
                                             <br>
                                             <span>176543876595</span>
                                        </p>
                                   </div>
								    <div class="col-md-4 col-sm-6">
                                        <p>
                                             <strong>Sold</strong>
                                             <br>
                                             <span>112980 Sold</span>
                                        </p>
                                   </div>
                              </div>
                         </form>
                    </div>
               </div>

               <div class="row">
                    <div class="col-lg-8 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Synopsis</h4>
                              </div>

                              <div class="panel-body">
                                   <p>To All the Boys I’ve Loved Before is the story of Lara Jean, 
								   who has never openly admitted her crushes, but instead wrote each 
								   boy a letter about how she felt, sealed it, and hid it in a box under 
								   her bed.</p>
								   <p>But one day Lara Jean discovers that somehow her secret box of 
								   letters has been mailed, causing all her crushes from her past to 
								   confront her about the letters: her first kiss, the boy from summer 
								   camp, even her sister's ex-boyfriend, Josh.</p>
								   <p>As she learns to deal with her past loves face to face, Lara 
								   Jean discovers that something good may come out of these letters after all.</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4 col-xs-12">
                         <div class="panel panel-default">
                              <div class="panel-heading">
                                   <h4>Contact Details</h4>
                              </div>

                              <div class="panel-body">
                                   <p>
                                        <span>Name</span>
                                        <br>
                                        <strong>Encik Misteri</strong>
                                   </p>

                                   <p>
                                        <span>Phone</span>
                                        <br>
                                        <strong><a href="019-6542143">019-6542143</a></strong>
                                   </p>

                                   <p>
                                        <span>Email</span>
                                        <br>
                                        <strong><a href="misteri@gmail.com">misteri@gmail.com</a></strong>
                                   </p>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>
	 
	 