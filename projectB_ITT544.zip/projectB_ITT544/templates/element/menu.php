<?php
	$c_name = $this->request->getParam('controller');
	$a_name = $this->request->getParam('action');
	
	//echo $a_name;
	//exit;

?>
 <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Books Store Website</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li class=<?= $a_name== 'home'?'active':''?>><a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'home']);?>>Home</a></li>
						 <li class=<?= $a_name== 'books'?'active':''?>><a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'books']);?>>Books</a></li>
	                     <li class=<?= $a_name== 'aboutUs'?'active':''?>><a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'aboutUs']);?>>About Us</a></li>
                         <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                              
                              <ul class="dropdown-menu">
			                         <li class=<?= $a_name== 'team'?'active':''?>><a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'team']);?>>Team</a></li>
			                         <li class=<?= $a_name== 'feedbacks'?'active':''?>><a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'feedbacks']);?>>Feedbacks</a></li>
                              </ul>
                         </li>
                         <li class=<?= $a_name== 'contactUs'?'active':''?>><a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'contactUs']);?>>Contact Us</a></li>
                    </ul>
               </div>

          </div>
     </section>