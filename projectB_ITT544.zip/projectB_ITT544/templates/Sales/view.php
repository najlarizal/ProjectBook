<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Sale $sale
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Sale'), ['action' => 'edit', $sale->salesID], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Sale'), ['action' => 'delete', $sale->salesID], ['confirm' => __('Are you sure you want to delete # {0}?', $sale->salesID), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Sales'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Sale'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="sales view content">
            <h3><?= h($sale->salesID) ?></h3>
            <table>
                <tr>
                    <th><?= __('SalesID') ?></th>
                    <td><?= $this->Number->format($sale->salesID) ?></td>
                </tr>
                <tr>
                    <th><?= __('CustomerID') ?></th>
                    <td><?= $this->Number->format($sale->customerID) ?></td>
                </tr>
                <tr>
                    <th><?= __('EmployeeID') ?></th>
                    <td><?= $this->Number->format($sale->employeeID) ?></td>
                </tr>
                <tr>
                    <th><?= __('Quantity') ?></th>
                    <td><?= $this->Number->format($sale->quantity) ?></td>
                </tr>
                <tr>
                    <th><?= __('Date') ?></th>
                    <td><?= h($sale->date) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Book') ?></h4>
                <?php if (!empty($sale->book)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('BookID') ?></th>
                            <th><?= __('Title') ?></th>
                            <th><?= __('Author') ?></th>
                            <th><?= __('Genre') ?></th>
                            <th><?= __('Publisher') ?></th>
                            <th><?= __('Unit') ?></th>
                            <th><?= __('Price') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($sale->book as $book) : ?>
                        <tr>
                            <td><?= h($book->bookID) ?></td>
                            <td><?= h($book->title) ?></td>
                            <td><?= h($book->author) ?></td>
                            <td><?= h($book->genre) ?></td>
                            <td><?= h($book->publisher) ?></td>
                            <td><?= h($book->unit) ?></td>
                            <td><?= h($book->price) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Book', 'action' => 'view', $book->bookID]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Book', 'action' => 'edit', $book->bookID]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Book', 'action' => 'delete', $book->bookID], ['confirm' => __('Are you sure you want to delete # {0}?', $book->bookID)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
