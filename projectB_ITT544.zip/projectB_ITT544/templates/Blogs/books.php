
     <section>
          <div class="container">
               <div class="text-center">
                    <h1><u>Book Listing</u></h1>

                    <br>
					<p class="lead">"A room without books is like a body without a soul" -Cicero-</p>
               </div>
          </div>
     </section>

     <section class="section-background">
          <div class="container">

             <div class="row">
				<div class="col-sm-12">
					<h2>Hello!</h2>
					<h4>Books Category.</h4>
					<p>You can choose the books category you want.</p>
				</div>
			 </div>
				<br><br>
                    <div class="col-lg-3 col-md-3">
                         <div class="form">
                              <form action="#">
                                   <div class="form-group">
                                        <label>Old/New:</label>

                                        <select class="form-control">
                                             <option value="">All</option>
                                             <option value="old">Old Books</option>
                                             <option value="new">New Books</option>
                                        </select>
                                   </div>
									<br><br>
									
                                   <div class="form-group">
                                        <label>Genres:</label>

                                        <select class="form-control">
                                             <option value="">--All --</option>
                                             <option value="">Horror</option>
                                             <option value="">Thriller</option>
                                             <option value="">Romance</option>
                                             <option value="">Mystery</option>
											 <option value="">Adventure</option>
                                        </select>
                                   </div>
									<br><br>
									
								   <div class="form-group">
                                        <label>Filters:</label>
                                        
                                        <select class="form-control">
                                             <option value="">-- All --</option>
                                             <option value="">Best Sellers</option>
                                             <option value="">New Releases</option>
                                        </select>
                                   </div>
								   
								   <br><br>
                                   <div class="form-group">
                                        <label>Price:</label>
                                        
                                        <select class="form-control">
                                             <option value="">-- All --</option>
                                             <option value="">Above MYR40</option>
                                             <option value="">Below MYR40</option>
                                        </select>
                                   </div>
								   <br>
                                   <button type="submit" class="section-btn btn btn-primary btn-block">Search</button>
                              </form>
                         </div>
						 <br><br>
						<div class="row">
							<div class="col-sm-12">
							<h3>MAKE BOOKS YOUR BESTFRIEND AND THEY WILL NEVER LEAVE YOU.</h3>
							</div>
						</div>
                    </div>
					



                    <div class="col-lg-9 col-md-3">
                         <div class="row">
						 
							<!-- BOOK ONE -->
                              <div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookone.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookonedetails']);?>>Wuthering Heights</a></h3>

                                             <p class="lead"><strong>MYR35.50</strong></p>

                                             <p>Mystery &nbsp;&nbsp;-&nbsp;&nbsp; 313 Pages &nbsp;&nbsp;-&nbsp;&nbsp; Old Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookonedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>

								<!-- BOOK TWO -->
                              <div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/booktwo.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwodetails']);?>>The Spider Goddess</a></h3>

                                             <p class="lead"><strong>MYR33.50</strong></p>

                                             <p>Horror &nbsp;&nbsp;-&nbsp;&nbsp; 415 Pages &nbsp;&nbsp;-&nbsp;&nbsp; Old Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwodetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>

								<!-- BOOK THREE -->
                              <div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookthree.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?>>Safe With Me</a></h3>

                                             <p class="lead"><strong>MYR39.90</strong></p>

                                             <p>Thriller &nbsp;&nbsp;-&nbsp;&nbsp; 440 Pages &nbsp;&nbsp;-&nbsp;&nbsp; Old Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>

								<!-- BOOK FOUR -->
                              <div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookfour.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfourdetails']);?>>Maze Runner : The Death Cure</a></h3>

                                             <p class="lead"><strong>MYR45.00</strong></p>

                                            <p>Mystery & Romance &nbsp;&nbsp;-&nbsp;&nbsp; 537 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfourdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>

								<!-- BOOK FIVE -->	
                              <div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookfive.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfivedetails']);?>>The Blood Countless</a></h3>

                                             <p class="lead"><strong>MYR38.50</strong></p>

                                             <p>Thriller &nbsp;&nbsp;-&nbsp;&nbsp; 430 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookfivedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>

								<!-- BOOK SIX -->
                              <div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/booksix.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'booksixdetails']);?>>Before We Were Yours</a></h3>

                                             <p class="lead"><strong>MYR43.50</strong></p>

                                             <p>Mystery & Romance &nbsp;&nbsp;-&nbsp;&nbsp; 570 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booksixdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
						</div>	  
					</div>		
					
					<div class="col-lg-9 col-md-4">
						<div class="row">
						
							<!-- BOOK SEVEN -->
							<div class="col-lg-4 col-md-3 col-sm-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
											
                                             <div class="courses-image">
											
                                                  <img src="/projectB_ITT544/webroot/img/bookseven.jpg" class="img-responsive" alt="">
											
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'booksevendetails']);?>>Death Comes To Call</a></h3>

                                             <p class="lead"><strong>MYR37.80</strong></p>

                                             <p>Horror &nbsp;&nbsp;-&nbsp;&nbsp; 350 Pages &nbsp;&nbsp;-&nbsp;&nbsp; Old Books</p>	
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booksevendetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
							  
							  <!-- BOOK EIGHT -->
							  <div class="col-lg-4 col-md-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookeight.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookeightdetails']);?>>The Girl In The Ice</a></h3>

                                             <p class="lead"><strong>MYR42.30</strong></p>

                                             <p>Romance &nbsp;&nbsp;-&nbsp;&nbsp; 400 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookeightdetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
							  
							  <!-- BOOK NINE -->
							   <div class="col-lg-4 col-md-3">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/booknine.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookninedetails']);?>>Murder Undeniable</a></h3>

                                             <p class="lead"><strong>MYR36.90</strong></p>

                                             <p>Thriller &nbsp;&nbsp;-&nbsp;&nbsp; 340 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookninedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
						</div>
					</div>
					
					<div class="col-lg-9 col-md-4">
						<div class="row">
						
							<!-- BOOK TEN -->
							<div class="col-lg-4 col-md-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
											
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookten.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktendetails']);?>A Hopeless Romantic</a></h3>

                                             <p class="lead"><strong>MYR40.80</strong></p>

                                             <p>Romance &nbsp;&nbsp;-&nbsp;&nbsp; 350 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>	
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktendetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
							  
							  <!-- BOOK ELEVEN -->
							  <div class="col-lg-4 col-md-4">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/bookeleven.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookelevendetails']);?>>To All The Boys I've Loved Before</a></h3>

                                             <p class="lead"><strong>MYR36.80</strong></p>

                                             <p>Romance &nbsp;&nbsp;-&nbsp;&nbsp; 455 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookelevendetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
							  
							  <!-- BOOK TWELVE -->
							   <div class="col-lg-4 col-md-3">
                                   <div class="courses-thumb courses-thumb-secondary">
                                        <div class="courses-top">
                                             <div class="courses-image">
                                                  <img src="/projectB_ITT544/webroot/img/booktwelve.jpg" class="img-responsive" alt="">
                                             </div>
                                        </div>

                                        <div class="courses-detail">
                                             <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwelvedetails']);?>>What I Like About You</a></h3>

                                             <p class="lead"><strong>MYR40.00</strong></p>

                                             <p>Romance &nbsp;&nbsp;-&nbsp;&nbsp; 378 Pages &nbsp;&nbsp;-&nbsp;&nbsp; New Books</p>
                                        </div>

                                        <div class="courses-info">
                                             <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwelvedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                        </div>
                                   </div>
                              </div>
						</div>
					</div>

					
               </div>
          </div>
     </section>