
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

 

     <!-- HOME -->
     <section id="home">
			  <div class="row">
				   <div class="owl-carousel owl-theme home-slider">
						<div class="item item-first">
							 <div class="caption">
								  <div class="container">
									   <div class="col-md-6 col-sm-12">
											<h1>WELCOME TO OUR BOOKSTORE WEBSITE</h1>
											<h3>We provides all the selling books from our local country to global.</h3>
											<a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'books']);?> class="section-btn btn btn-default">Browse Books</a>
									   </div>
								  </div>
							 </div>
						</div>

						<div class="item item-second">
							 <div class="caption">
								  <div class="container">
									   <div class="col-md-6 col-sm-12">
											<h1>OFFERS</h1>
											<h3>we will have offers on JANUARY until JULY to our beloved customers. dont miss out your chances.  </h3>
											<a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'books']);?> class="section-btn btn btn-default">Browse Books</a>
									   </div>
								  </div>
							 </div>
						</div>

						<div class="item item-third">
							 <div class="caption">
								  <div class="container">
									   <div class="col-md-6 col-sm-12">
											<h1>FAREWELL</h1>
											<h3>we wish your enjoy your time here and recommend us to your friends. don't forget to come again and support us.</h3>
											<a href=<?= $this->Url->build(['controller'=>'blogs','action'=>'books']);?> class="section-btn btn btn-default">Browse Books</a>
									   </div>
								  </div>
							 </div>
						</div>
				   </div>
			  </div>
     </section>

     <main>
          <section>
               <div class="container">
                    <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <div class="text-center">
                                   <h2>About us</h2>

                                   <br>

                                   <p class="lead">we are a company that provides all types of rare books for our lovely customers. try find your books here and we guarantee your satisfaction.</p>
                              </div>
                         </div>
                    </div>
               </div>
          </section>
          
<section>
               <div class="container">
                    <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <div class="section-title text-center">
                                   <h2>Featured Books <small>Best out of the bestselling books</small></h2>
                              </div>
                         </div>

                         <div class="col-md-4 col-sm-4">
                              <div class="courses-thumb courses-thumb-secondary">
                                   <div class="courses-top">
                                        <div class="courses-image">
                                             <img src="/projectB_ITT544/webroot/img/bookone.jpg" class="img-responsive" alt="">
                                        </div>
                                   </div>

                                   <div class="courses-detail">
                                        <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookonedetails']);?>> Wuthering Heights</a></h3>

                                        <p class="lead"> <strong>MYR35.50</strong></p>

                                        <p>Mystery &nbsp;&nbsp;/&nbsp;&nbsp; 313 pages &nbsp;&nbsp;/&nbsp;&nbsp; Old Books</p>
                                   </div>

                                   <div class="courses-info">
                                        <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookonedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                   </div>
                              </div>
                         </div>

                         <div class="col-md-4 col-sm-4">
                              <div class="courses-thumb courses-thumb-secondary">
                                   <div class="courses-top">
                                        <div class="courses-image">
                                             <img src="/projectB_ITT544/webroot/img/booktwo.jpg" class="img-responsive" alt="">
                                        </div>
                                   </div>

                                   <div class="courses-detail">
                                        <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwodetails']);?>> The Spider Goddess</a></h3>

                                        <p class="lead"> <strong>MYR33.50</strong></p>

                                        <p>Horror &nbsp;&nbsp;/&nbsp;&nbsp; 415 Pages &nbsp;&nbsp;/&nbsp;&nbsp; Old Books</p>
                                   </div>

                                   <div class="courses-info">
                                        <a href=<?= $this->Url->build(['controller'=>'books','action'=>'booktwodetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                   </div>
                              </div>
                         </div>

                         <div class="col-md-4 col-sm-4">
                              <div class="courses-thumb courses-thumb-secondary">
                                   <div class="courses-top">
                                        <div class="courses-image">
                                             <img src="/projectB_ITT544/webroot/img/bookthree.jpg" class="img-responsive" alt="">
                                        </div>
                                   </div>

                                   <div class="courses-detail">
                                        <h3><a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?>>Safe With Me</a></h3>

                                        <p class="lead"> <strong>MYR39.90</strong></p>

                                        <p>Thriller &nbsp;&nbsp;/&nbsp;&nbsp; 440 Pages &nbsp;&nbsp;/&nbsp;&nbsp; Old Books</p>
                                   </div>

                                   <div class="courses-info">
                                        <a href=<?= $this->Url->build(['controller'=>'books','action'=>'bookthreedetails']);?> class="section-btn btn btn-primary btn-block">View More</a>
                                   </div>
                              </div>
                         </div>

                    </div>
               </div>
          </section>
          

          

          <section id="testimonial">
               <div class="container">
                    <div class="row">

                         <div class="col-md-12 col-sm-12">
                              <div class="section-title text-center">
                                   <h2>Testimonials <small>from around the world</small></h2>
                              </div>

                              <div class="owl-carousel owl-theme owl-client">
                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="/projectB_ITT544/webroot/img/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>Jackson</h4>
                                                  <span>Shopify Developer</span>
                                             </div>
                                             <p>Well at least someone different is getting shot in the head for once.</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="/projectB_ITT544/webroot/img/tst-image-2-200x216.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>Camila</h4>
                                                  <span>Marketing Manager</span>
                                             </div>
                                            <p>I love Medea so much. It's so different from the other ones I have read and it reminds me of a story that i love. Medea being a bad ass while being a body that's weaker than she is used to is just... amazing! I'm so ready for more.</p>
                                            <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="/projectB_ITT544/webroot/img/tst-image-3-200x216.jpg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>Barbie</h4>
                                                  <span>Art Director</span>
                                             </div>
                                             <p>This is one of my favourites because the plot is different from the others. In this story, no one is bad completely and no one is good completely. They're the same. They are humans. This story lets us know that there's nothing as absolutely right. i really like that no one is really the bad guy here. we may detest the Crown Prince, but we can't deny that he is brilliant, isn't it?</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>
								   
								   <div class="col-md-4 col-sm-4">
                                        <div class="item">
                                             <div class="tst-image">
                                                  <img src="/projectB_ITT544/webroot/img/hazim2.jpeg" class="img-responsive" alt="">
                                             </div>
                                             <div class="tst-author">
                                                  <h4>jatjim a.k.a koro sensei</h4>
                                                  <span>teacher at assassination classroom</span>
                                             </div>
                                             <p>as someone who purely love kids and fighting, books here are really fill my anxious of wanting to live in this world.</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
												  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>

                              </div>
                        </div>
                    </div>
               </div>
          </section> 
     </main>

     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="section-title">
                                   <h2>Contact us <small>we love conversations. let us talk!</small></h2>
                              </div>

                              <div class="col-md-12 col-sm-12">
                                   <input type="text" class="form-control" placeholder="Enter full name" name="name" required>
                    
                                   <input type="email" class="form-control" placeholder="Enter email address" name="email" required>

                                   <textarea class="form-control" rows="6" placeholder="Tell us about your message" name="message" required></textarea>
                              </div>

                              <div class="col-md-4 col-sm-12">
                                   <input type="submit" class="form-control" name="send message" value="Send Message">
                              </div>

                         </form>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="contact-image">
                              <img src="/projectB_ITT544/webroot/img/contact-1-600x400.jpg" class="img-responsive" alt="Smiling Two Girls">
                         </div>
                    </div>

               </div>
          </div>
     </section>       

     

</body>
