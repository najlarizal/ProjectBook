     <section class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-offset-1 col-md-4 col-xs-12 pull-right">
                         <img src="images/about-1-720x720.jpg" class="img-responsive img-circle" alt="">
                    </div>

                    <div class="col-md-7 col-xs-12">
                         <div class="about-info">
                              <h2>FIRST STEP TO BE THE BEST BOOK PUBLISHER IN THE WORLD</h2>

                              <figure>
                                   <figcaption>

                                        <p>Established in January 1987, ISSN Story Telling Company Sdn Bhd has become a household name in London and has now grown to more than 97 stores countrywide. It is recognised and listed by the World Book of Records as the largest bookstore chain in London, with over 800,000 square feet of retail space. ISSN Story Telling Company Sdn Bhd is 100% managed by Malaysians and is strongly positioned as a trilingual one-stop bookstore catering for everyone from all walks of life. ISSN Stoy Telling sells a wide variety of fiction, non-fiction and general interest books in English languages. In addition, it also offers a large selection of magazines, stationery, multi-media products, gift items and CDs. Its 4 mega stores in the Brent Park, Dollis Hills and Finchley offer a conducive and relaxing ambience for a whole new reading and browsing experience. In addition to retailing, ISSN Story Telling Company Sdn Bhd has 3 other core businesses: book distribution, publishing and e-learning. ISSN Story Telling Company is continuously re-inventing itself to become a customer-centric and dynamic retailer of the new millennium</p>
									</figcaption>
                              </figure>
                         </div>
                    </div>
               </div>
          </div>
     </section>

     <section>
          <div class="container">
               <div class="row">
                    <div class="col-md-4 col-xs-12">
                         <img src="images/about-2-720x720.jpg" class="img-responsive img-circle" alt="">
                    </div>

                    <div class="col-md-offset-1 col-md-7 col-xs-12">
                         <div class="about-info">
                              <h2>OUR OBJECTIVES</h2>

                              <figure>
                                   <figcaption>
                                        <p>Our Bookstore Website are convenience for our customer. It can be downloaded to a computer, PC, Mac, laptop, tablet, smartphone or any other kind of the device and can buy any books here. Bookstore Website offer many benefits and advantages. It is very simple and easy to purchase and buy books through the Internet. It is exactly like purchasing any other product. The only difference is that after payment you will either be directed to a download page or receive the download link in an email. All you have to do is click on the link and the our website will automatically get you data and accept your book purchase.</p>

                                   </figcaption>
                              </figure>
                         </div>
                    </div>
               </div>
          </div>
     </section>

     <section class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="text-center">
                              <h2> FINAL WORDS TO FELLOW SUPPORTERS</h2>

                              <br>

                              <p class="lead">Our bookstore website provide the best for you to easily buy your book. For your information, our books are also among the best-selling books and new releases books on the market. If you have any questions call us at our number listed below. Hope you enjoy with our website. Enjoy it!</p>
                         </div>
                    </div>
               </div>
          </div>
     </section>
