     <!-- TESTIMONIAL -->
     <section id="testimonial" class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="/projectB_ITT544/webroot/img/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>Jackson</h4>
                                   <span>Operating Manager</span>
                              </div>
                              <p>CoFounding The Right Way book is a great starting point for those that are planning a business partnership, or in the process of working with a team of cofounders. Highly recommended hands-on book with some great examples of partnership done right and wrong!</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="/projectB_ITT544/webroot/img/tst-image-2-200x216.jpg" class="img-responsive" alt="">
                              </div>
                               <div class="tst-author">
                                   <h4>Camila</h4>
                                   <span>Marketing Manager</span>
                              </div>
                              <p>I love Medea so much. It's so different from the other ones I have read and it reminds me of a story that i love. Medea being a bad ass while being a body that's weaker than she is used to is just... amazing! I'm so ready for more.</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="/projectB_ITT544/webroot/img/tst-image-3-200x216.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>Mariposa</h4>
                                   <span>Art Director</span>
                              </div>
                              <p>This is one of my favourites because the plot is different from the others. In this story, no one is bad completely and no one is good completely. They're the same. They are humans. This story lets us know that there's nothing as absolutely right. i really like that no one is really the bad guy here. we may detest the Crown Prince, but we can't deny that he is brilliant, isn't it?</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>
               </div>
               
               <div class="row">
                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="/projectB_ITT544/webroot/img/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>James</h4>
                                   <span>Shopify Developer</span>
                              </div>
                              <p>Well at least someone different is getting shot in the head for once.</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>

                    <div class="col-sm-4 col-xs-12">
                         <div class="item">
                              <div class="tst-image">
                                   <img src="/projectB_ITT544/webroot/img/tst-image-2-200x216.jpg" class="img-responsive" alt="">
                              </div>
                              <div class="tst-author">
                                   <h4>Barbie</h4>
                                   <span>Art Director</span>
                              </div>
                              <p>I mean this in the best way, because i absolutely love this story; This has got to be the worst meet ups for those two. I love it!</p>
                              <div class="tst-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                              </div>
                         </div>
                    </div>
	
					<div class="col-sm-4 col-xs-12">
                          <div class="item">
                                  <div class="tst-image">
                                         <img src="/projectB_ITT544/webroot/img/hazim2.jpeg" class="img-responsive" alt="">
                                   </div>
                                             <div class="tst-author">
                                                  <h4>jatjim a.k.a koro sensei</h4>
                                                  <span>teacher at assassination classroom</span>
                                             </div>
                                             <p>as someone who purely love kids and fighting, books here are really fill my anxious of wanting to live in this world.</p>
                                             <div class="tst-rating">
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                             </div>
                                        </div>
                                   </div>
               </div>
          </div>
     </section> 