     <section>
          <div class="container">
               <div class="text-center">
                    <h1>Team</h1>

                    <br>

                    <p class="lead">We are a group of people that comitted and loves books so much until we could die for books :3</p>
               </div>
          </div>
     </section>
	 
     <section id="team" class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="/projectB_ITT544/webroot/img/hazim2.jpeg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>Nurizat Hazim</h3>
                                   <span>top management</span>
                              </div>
                              <ul class="social-icon">
                                   <li><a href="https://www.facebook.com/nurizat.hazim" class="fab fa-facebook" attr="facebook icon"></a></li>
                                   <li><a href="https://twitter.com/IjatHazim?s=09" class="fab fa-twitter"></a></li>
                                   <li><a href="https://www.instagram.com/izat_azim?r=nametag" class="fab fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="/projectB_ITT544/webroot/img/shue2.jpeg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>Nur Syuhada</h3>
                                   <span>CEO</span>
                              </div>
                              <ul class="social-icon">
                                   <li><a href="#" class="fab fa-twitter"></a></li>
                                   <li><a href="#" class="fab fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="/projectB_ITT544/webroot/img/najla.jpeg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>Najla Nafisa</h3>
                                   <span>Marketing Expert</span>
                              </div>
                              <ul class="social-icon">
  
                                   <li><a href="https://instagram.com/najlarizal?igshid=1f7yrfdgaa0fl" class="fab fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="team-image">
                                   <img src="/projectB_ITT544/webroot/img/sofieya.jpeg" class="img-responsive" alt="">
                              </div>
                              <div class="team-info">
                                   <h3>Sofieya</h3>
                                   <span>Customer Support</span>
                              </div>
                              <ul class="social-icon">
                                   <li><a href="#" class="fab fa-twitter"></a></li>
                                   <li><a href="#" class="fab fa-google"></a></li>
                                   <li><a href="#" class="fab fa-behance"></a></li>
                              </ul>
                         </div>
                    </div>
               </div>
          </div>
          </section>
