<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SalesBook $salesBook
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Sales Book'), ['action' => 'edit', $salesBook->SbookID], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Sales Book'), ['action' => 'delete', $salesBook->SbookID], ['confirm' => __('Are you sure you want to delete # {0}?', $salesBook->SbookID), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Sales Book'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Sales Book'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="salesBook view content">
            <h3><?= h($salesBook->SbookID) ?></h3>
            <table>
                <tr>
                    <th><?= __('SbookID') ?></th>
                    <td><?= $this->Number->format($salesBook->SbookID) ?></td>
                </tr>
                <tr>
                    <th><?= __('SalesID') ?></th>
                    <td><?= $this->Number->format($salesBook->salesID) ?></td>
                </tr>
                <tr>
                    <th><?= __('BookID') ?></th>
                    <td><?= $this->Number->format($salesBook->bookID) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
