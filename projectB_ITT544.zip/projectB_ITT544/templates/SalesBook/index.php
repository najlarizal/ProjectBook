<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SalesBook[]|\Cake\Collection\CollectionInterface $salesBook
 */
?>
<div class="salesBook index content">
    <?= $this->Html->link(__('New Sales Book'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Sales Book') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('SbookID') ?></th>
                    <th><?= $this->Paginator->sort('salesID') ?></th>
                    <th><?= $this->Paginator->sort('bookID') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($salesBook as $salesBook): ?>
                <tr>
                    <td><?= $this->Number->format($salesBook->SbookID) ?></td>
                    <td><?= $this->Number->format($salesBook->salesID) ?></td>
                    <td><?= $this->Number->format($salesBook->bookID) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $salesBook->SbookID]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $salesBook->SbookID]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $salesBook->SbookID], ['confirm' => __('Are you sure you want to delete # {0}?', $salesBook->SbookID)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
