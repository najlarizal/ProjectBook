<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SalesBookTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SalesBookTable Test Case
 */
class SalesBookTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SalesBookTable
     */
    protected $SalesBook;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.SalesBook',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('SalesBook') ? [] : ['className' => SalesBookTable::class];
        $this->SalesBook = TableRegistry::getTableLocator()->get('SalesBook', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->SalesBook);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
