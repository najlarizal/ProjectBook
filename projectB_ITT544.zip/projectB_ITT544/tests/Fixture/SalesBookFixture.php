<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SalesBookFixture
 */
class SalesBookFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'sales_book';
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'SbookID' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'salesID' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'bookID' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        '_indexes' => [
            'salesID' => ['type' => 'index', 'columns' => ['salesID', 'bookID'], 'length' => []],
            'bookID' => ['type' => 'index', 'columns' => ['bookID'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['SbookID'], 'length' => []],
            'sales_book_ibfk_1' => ['type' => 'foreign', 'columns' => ['bookID'], 'references' => ['book', 'bookID'], 'update' => 'cascade', 'delete' => 'cascade', 'length' => []],
            'sales_book_ibfk_2' => ['type' => 'foreign', 'columns' => ['salesID'], 'references' => ['sales', 'salesID'], 'update' => 'cascade', 'delete' => 'cascade', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'SbookID' => 1,
                'salesID' => 1,
                'bookID' => 1,
            ],
        ];
        parent::init();
    }
}
