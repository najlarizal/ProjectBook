<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SalesFixture
 */
class SalesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'salesID' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'customerID' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'employeeID' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'date' => ['type' => 'date', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'quantity' => ['type' => 'integer', 'length' => 255, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        '_indexes' => [
            'customerID' => ['type' => 'index', 'columns' => ['customerID', 'employeeID'], 'length' => []],
            'employeeID' => ['type' => 'index', 'columns' => ['employeeID'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['salesID'], 'length' => []],
            'sales_ibfk_1' => ['type' => 'foreign', 'columns' => ['customerID'], 'references' => ['customer', 'CustomerID'], 'update' => 'cascade', 'delete' => 'cascade', 'length' => []],
            'sales_ibfk_2' => ['type' => 'foreign', 'columns' => ['employeeID'], 'references' => ['employee', 'EmployeeID'], 'update' => 'cascade', 'delete' => 'cascade', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'salesID' => 1,
                'customerID' => 1,
                'employeeID' => 1,
                'date' => '2020-07-01',
                'quantity' => 1,
            ],
        ];
        parent::init();
    }
}
