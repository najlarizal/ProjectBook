<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SalesBook Model
 *
 * @method \App\Model\Entity\SalesBook newEmptyEntity()
 * @method \App\Model\Entity\SalesBook newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\SalesBook[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SalesBook get($primaryKey, $options = [])
 * @method \App\Model\Entity\SalesBook findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\SalesBook patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SalesBook[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\SalesBook|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SalesBook saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SalesBook[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\SalesBook[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\SalesBook[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\SalesBook[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class SalesBookTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('sales_book');
        $this->setDisplayField('SbookID');
        $this->setPrimaryKey('SbookID');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('SbookID')
            ->allowEmptyString('SbookID', null, 'create');

        $validator
            ->integer('salesID')
            ->allowEmptyString('salesID');

        $validator
            ->integer('bookID')
            ->allowEmptyString('bookID');

        return $validator;
    }
}
