<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * SalesBook Controller
 *
 * @property \App\Model\Table\SalesBookTable $SalesBook
 * @method \App\Model\Entity\SalesBook[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SalesBookController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $salesBook = $this->paginate($this->SalesBook);

        $this->set(compact('salesBook'));
    }

    /**
     * View method
     *
     * @param string|null $id Sales Book id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $salesBook = $this->SalesBook->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('salesBook'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $salesBook = $this->SalesBook->newEmptyEntity();
        if ($this->request->is('post')) {
            $salesBook = $this->SalesBook->patchEntity($salesBook, $this->request->getData());
            if ($this->SalesBook->save($salesBook)) {
                $this->Flash->success(__('The sales book has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sales book could not be saved. Please, try again.'));
        }
        $this->set(compact('salesBook'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Sales Book id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $salesBook = $this->SalesBook->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $salesBook = $this->SalesBook->patchEntity($salesBook, $this->request->getData());
            if ($this->SalesBook->save($salesBook)) {
                $this->Flash->success(__('The sales book has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sales book could not be saved. Please, try again.'));
        }
        $this->set(compact('salesBook'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Sales Book id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $salesBook = $this->SalesBook->get($id);
        if ($this->SalesBook->delete($salesBook)) {
            $this->Flash->success(__('The sales book has been deleted.'));
        } else {
            $this->Flash->error(__('The sales book could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
