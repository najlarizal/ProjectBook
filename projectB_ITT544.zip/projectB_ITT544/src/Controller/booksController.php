<?php

namespace App\Controller;
use Cake\Event\EventInterface;

class booksController extends AppController{

public function beforeFilter(EventInterface $event)
	{
		$this->viewBuilder()->setLayout('booksnav');
		//debug($event);
		//exit;
	}
	
		public function bookonedetails()
	{
	//
	}
	
		public function booktwodetails()
	{
	//
	}
	
		public function bookthreedetails()
	{
	//
	}
	
		public function bookfourdetails()
	{
	//
	}
	
		public function bookfivedetails()
	{
	//
	}
	
		public function booksixdetails()
	{
	//
	}
	
		public function booksevendetails()
	{
	//
	}
	
		public function bookeightdetails()
	{
	//
	}
	
		public function bookninedetails()
	{
	//
	}
	
		public function booktendetails()
	{
	//
	}
	
		public function bookelevendetails()
	{
	//
	}
	
		public function booktwelvedetails()
	{
	//
	}
	
	
}